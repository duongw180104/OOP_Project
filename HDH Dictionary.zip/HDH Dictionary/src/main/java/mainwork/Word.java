package mainwork;

public class Word {
    private String WordInput;
    private String WordExplain;
    public Word(String WordInput, String WordExplain){
        this.WordExplain = WordExplain;
        this.WordInput = WordInput;
    }

    public String getWordInput() {
        return WordInput;
    }

    public String getWordExplain() {
        return WordExplain;
    }

    public void setWordExplain(String wordExplain) {
        WordExplain = wordExplain;
    }

    public void setWordInput(String wordInput) {
        WordInput = wordInput;
    }
}
