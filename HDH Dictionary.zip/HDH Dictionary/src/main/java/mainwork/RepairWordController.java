package mainwork;

public class RepairWordController {
}
