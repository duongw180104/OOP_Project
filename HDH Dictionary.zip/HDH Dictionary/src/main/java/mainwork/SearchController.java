package mainwork;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

public class SearchController implements Initializable {
    private static final String FILENAME = "D:\\Code\\HDH Dictionary\\src\\data.txt";
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button saved_button;
    @FXML
    private Button history_button;
    @FXML
    private Button game_button;
    @FXML
    private Button addword_button;
    @FXML
    private Button speaker_button;
    @FXML
    private Button delete_button;
    @FXML
    private Button repair_button;
    @FXML
    private Button favorite_button;
    @FXML
    private Button search_button;
    public void setImage(){
        Image search_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\search.png");
        ImageView imageViewSearch = new ImageView(search_icon);
        search_button.setGraphic(imageViewSearch);

        Image saved_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\save-instagram.png");
        ImageView imageViewSaved = new ImageView(saved_icon);
        saved_button.setGraphic(imageViewSaved);

        Image history_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\history.png");
        ImageView imageViewHistory = new ImageView(history_icon);
        history_button.setGraphic(imageViewHistory);

        Image game_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\game-console.png");
        ImageView imageViewGame = new ImageView(game_icon);
        game_button.setGraphic(imageViewGame);

        Image delete_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\delete.png");
        ImageView imageViewDelete = new ImageView(delete_icon);
        delete_button.setGraphic(imageViewDelete);

        Image add_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\Add.png");
        ImageView imageViewAdd = new ImageView(add_icon);
        addword_button.setGraphic(imageViewAdd);

        Image repair_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\correction.png");
        ImageView imageViewRepair = new ImageView(search_icon);
        repair_button.setGraphic(imageViewRepair);

        Image speaker_icon  = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\speaker-filled-audio-tool.png");
        ImageView imageViewSpeaker = new ImageView(speaker_icon);
        saved_button.setGraphic(imageViewSpeaker);

        Image favorite_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\delete.png");
        ImageView imageViewFavorite= new ImageView(favorite_icon);
        favorite_button.setGraphic(imageViewFavorite);
    }




    public SearchController() throws IOException {
    }


    public void SwitchToAddWindow(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("AddWord.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Add Word");
//        Image add_icon = new Image("D:\\Code\\HDH Dictionary\\src\\Icons\\Add.png");
//        stage.getIcons().add(add_icon);


        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void SwitchToRepairWindow(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("RepairWord.fxml"));
        Stage stage = new Stage();
        stage.setTitle("RepairWord");
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }




List<String> words = Files.readAllLines(new File(FILENAME).toPath(), Charset.defaultCharset() );



    @FXML
    void search(ActionEvent event) {
        listView.getItems().clear();
        listView.getItems().addAll(searchList(searchBar.getText(),words));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listView.getItems().addAll(words);
    }

    private List<String> searchList(String searchWords, List<String> listOfStrings) {

        List<String> searchWordsArray = Arrays.asList(searchWords.trim().split(" "));

        return listOfStrings.stream().filter(input -> {
            return searchWordsArray.stream().allMatch(word ->
                    input.toLowerCase().contains(word.toLowerCase()));
        }).collect(Collectors.toList());
    }


    @FXML
    private TextField searchBar;

    @FXML
    private ListView<String> listView;


    @FXML
    private void handleClickListView() {
        listView.setOnMouseClicked(mouseEvent -> {
            String selectedWord = listView.getSelectionModel().getSelectedItems().toString();
            definitionLabel.setText(DictionarySearcher(selectedWord));
        });
    }

    @FXML
    private Label definitionLabel;


    public String DictionarySearcher(String search) {
        boolean found = false;

        try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                if (parts.length == 2) {
                    String word = parts[0].trim().toLowerCase();
                    String definition = parts[0].trim();
                    if (word.equals(search)) {
                        found = true;
                        System.out.println(definition);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!found) {

        }
        return search;
    }



    private static final String SaveFile = "D:\\Code\\HDH Dictionary\\src\\SavedList.txt";





    @FXML
    private void handleClickFavoriteButton(){
        appendToFile(definitionLabel.getText());
        isFavorite = true;
    }
    private boolean isFavorite;
    public void appendToFile(String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SaveFile, true))) {
            if (!isFavorite) {
                writer.write(content);
                writer.newLine(); // Thêm dòng mới sau nội dung mới chèn vào
                System.out.println("Từ đã được thêm vào file '" + SaveFile + "'.");
                isFavorite = true;
            }
            else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Từ đã được thêm!");
            }
        } catch (IOException e) {
            System.err.println("Lỗi: Không thể thêm từ vào file.");
            e.printStackTrace();
        }
    }
























//    @FXML
//    ImageView myImageView;
//    Image translate = new Image("file:translate.png");
//
//    public void displayImage(){
//        myImageView.setImage(translate);
}




