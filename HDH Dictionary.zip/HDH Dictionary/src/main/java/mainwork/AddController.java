package mainwork;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AddController {

    @FXML
    private TextField wordTextField;

    @FXML
    private TextField meaningTextField;

    @FXML
    private Button addButton;
    @FXML
    private Button exitButton;
    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }
    @FXML
    private void exitWindow(ActionEvent event){
        stage.close();
    }

    @FXML
    private void initialize() {
        addButton.setOnAction(e -> {
            String word = wordTextField.getText().trim();
            String meaning = meaningTextField.getText().trim();

            if (!word.isEmpty() && !meaning.isEmpty()) {
                appendToFile(word, meaning);
                wordTextField.clear();
                meaningTextField.clear();
            }
        });
    }

//    private void addWordToFile(String word, String meaning) {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\Code\\HDH Dictionary\\src\\data.txt", true))) {
//            writer.write(word + ": " + meaning);
//            writer.newLine();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
private static final String SaveFile = "D:\\Code\\HDH Dictionary\\src\\data.txt";
   @FXML
    public static void appendToFile(String word, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SaveFile, true))) {
            writer.write(word);
            writer.write(content);
            writer.newLine();
//            System.out.println("Từ đã được thêm vào file '" + SaveFile + "'.");
        } catch (IOException e) {
            System.err.println("Lỗi: Không thể thêm từ vào file.");
            e.printStackTrace();
        }
    }
}
