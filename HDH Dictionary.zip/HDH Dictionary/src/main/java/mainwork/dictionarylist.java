package mainwork;

import java.util.ArrayList;

public class dictionarylist {
    public static ArrayList<Word> ListForSearch = new ArrayList<>();
}
