package mainwork;
import javafx.event.ActionEvent;

import java.sql.Connection;


public class controller {
    public void connectButton(ActionEvent event){
        databaseconnection connectnow = new databaseconnection();
        Connection connectDB = connectnow.getConnection();
//        String connectQuery =
    }
}
