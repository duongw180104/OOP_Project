module mainwork {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;


    opens mainwork to javafx.fxml;
    exports mainwork;
}